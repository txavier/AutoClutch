﻿==================================
JSNLog is not yet fully installed
==================================

To finish the installation, two more steps need to be done. See

http://jsnlog.com/Documentation/DownloadInstall#additional
