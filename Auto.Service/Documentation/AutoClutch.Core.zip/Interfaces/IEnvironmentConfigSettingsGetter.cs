﻿namespace $safeprojectname$.Interfaces
{
    public interface IEnvironmentConfigSettingsGetter
    {
        string GetDocumentManagementSystemFolderName();
    }
}