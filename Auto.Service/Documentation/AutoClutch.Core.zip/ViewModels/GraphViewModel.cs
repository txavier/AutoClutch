﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.ViewModels
{
    public class GraphViewModel
    {
        public string label { get; set; }

        public string series { get; set; }

        public int data { get; set; }
    }
}
